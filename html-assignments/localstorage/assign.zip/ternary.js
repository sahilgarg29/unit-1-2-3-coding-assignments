// ------------- P1 ------------------

var input = 288;

var ans = input % 2 === 0 ? 'EVEN' : 'ODD';

console.log(ans);

// ---------------- p2 --------------------

var age = 19;

var answer =
  age > 18
    ? 'You can drive in India!'
    : age < 18
    ? "You can't drive in India!"
    : 'You are just old enough to drive in India!';

console.log(answer);
